version_flag = "v0.1.0"

from scripts.roop_logging import logger

logger.info(f"NSFW-Roop {version_flag}")
